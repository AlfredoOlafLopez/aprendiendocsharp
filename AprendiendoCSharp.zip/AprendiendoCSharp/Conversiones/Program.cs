﻿using System;

namespace Conversiones
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //En este vamos a declarar una variable de todo tipo, vamos a hacer un programa que te,
            //crea una y veamos como usarla, ya que se utilizaran para hacer todo tipo de funcione.
            //tanto numericas como de cadena.

            //Declaracion de variable
            string numero = "1234";
            //Aqui vamos a crear uno numerico para escribirlo.
            Console.WriteLine(numero.GetType().ToString());
            int intnumero = Convert.ToInt32(numero);
            Console.WriteLine(intnumero.GetType().ToString());
            Console.WriteLine(string.Format("el numero es {0}",
            intnumero));
            Console.ReadLine();
        }
    }
}
