﻿using System;

namespace Entrada
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Aqui hay que declarar una variabe para recivir la informacion.
            //Y otra para el valor equivalente, esto es muy comun.
            string valor;
            int receptora = 0;
            Console.Write("escribe algo: ");
            valor = Console.ReadLine();

            //Aqui podemos ver como se acepta un valor y se convierte en int.
            if (int.TryParse(valor, out receptora))
            {
                Console.WriteLine(
                string.Format("dato entero {0}. muy bien",
                receptora));
            }
            else
            {
                Console.WriteLine("dato no es entero. intentar de nuevo");
            }
            //Aqui pondremos pausa
            Console.WriteLine();
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
