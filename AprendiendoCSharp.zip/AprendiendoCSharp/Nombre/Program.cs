﻿using System;
using System.Text;

namespace Nombre
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //En este programa vamos a cambiar un texto a mayusculas
            //es de total importancia saberlo, ya que en algunos programas, nos van
            //A pedir que llenemos un registro con cierto tamaÒo de letra
            //y sabiendo esto, nos podremos ahorrar muchas lineas de codigo

            string nombre;
            string apellidos;
            Console.Write("Captura un nombre");
            nombre = Console.ReadLine();
            Console.Write("Captura un apellido");
            apellidos = Console.ReadLine();

            nombre = nombre.ToUpper();
            StringBuilder nombrecompleto = new StringBuilder(nombre);
            nombrecompleto.Append(" ");
            nombrecompleto.Append(apellidos);

            Console.WriteLine(nombrecompleto);

            //aqui vamos a poner pausa para cerrar


            Console.WriteLine();
            Console.ReadLine();
            Console.ReadKey();
        }
    }
}
