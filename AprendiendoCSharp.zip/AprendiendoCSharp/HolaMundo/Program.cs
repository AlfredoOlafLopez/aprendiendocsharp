﻿using System;
//Autor: Alfredo Olaf López Acuña
//Fecha: 1 de Octubre
namespace HolaMundo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //En este programa vamos a hacer algo totalmente basico dentro de la plataforma,
            //como lo es, mandar un mensaje.

            Console.WriteLine("Hola mundo, ahora en c#!");
            Console.ReadLine();
        }
    }
}
