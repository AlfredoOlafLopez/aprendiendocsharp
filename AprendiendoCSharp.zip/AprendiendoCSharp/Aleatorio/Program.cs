﻿using System;

namespace Aleatorio
{
    class MainClass
    {
        //Vamos a crear una variable publica.
        //Es importante ya que nos evitamos mucho trabajo.
        static public float numero1 = 24.5F;
        static void Main(string[] args)
        {
            float numero2 = 0.0F;
            Random numaleatorio = new Random();
            numero2 = (float)numaleatorio.Next(1, 11);
            Console.WriteLine(string.Format(
            "la suma de {0} y {1} es {2}",
            numero1, numero2, numero1 + numero2));
            Console.ReadLine();

        }
    }
}
